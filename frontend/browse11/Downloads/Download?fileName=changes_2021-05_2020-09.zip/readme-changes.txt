changes_...-main.xlsx file contains changes made in the main chapters of the classification in
 between these two releases versions
changes_...-extensions.xlsx contains the changes made in the extension codes chapters

Explanation of the status column:
- NewlyAdded            : This entity is added to the foundation and to the MMS in this release
- Removed               : Removed from the classification in this release
- MovedAboveShoreline   : The entity was in the foundation but it wasn't in the MMS in the previous
                          release. Now it is in the MMS
- MovedUnderShoreline   : The entity is no longer in MMS but it is still in the foundation
- MovedTo               : The entity is moved from one location to another and because of this its code has changed
                